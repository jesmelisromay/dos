package num3;

public interface Relaciones {
	
	 public boolean esMayor(Object b) throws excepcion;
	 public boolean esMenor(Object b) throws excepcion;
	 public boolean esIgual(Object b) throws excepcion;

}
