package num3;

public class excepcion extends Exception{
	
	public excepcion(String str){
		super(str);	
	}
	public excepcion(){
		super();	
	}		

}
