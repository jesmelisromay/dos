package num1;

public interface Estadisticas {

	double minimo();
	double maximo();
	double sumatorio();

}
